##################################
######### Anas Zughayyar #########
##################################
#### Python Stack Assignments ####
##################################
##########     Zoo     ###########
##################################

## Class Zoo

from Animal import Animal
from Lion import Lion
from Tiger import Tiger

class Zoo:
    def __init__(self):